export default function Contact() {
  return (
    <>
      <h1>Contact Page</h1>
    </>
  );
}
